Cloudfont Endpoint:
https://d1pus0vltf5qu.cloudfront.net


Bucket website endpoint:
http://my-225668711890-bucket.s3-website-us-east-1.amazonaws.com
